# 📱 Guide d'installation — Suivi des Paiements sur GitHub Pages

---

## 📁 Fichiers à déployer (4 fichiers)

```
index.html      ← L'application principale
manifest.json   ← Rend l'app installable
sw.js           ← Permet le mode hors-ligne
icon-192.png    ← Icône de l'app (petit)
icon-512.png    ← Icône de l'app (grand)
```

---

## 🚀 Étapes GitHub Pages (10 minutes)

### Étape 1 — Créer un compte GitHub
1. Allez sur **https://github.com**
2. Cliquez **Sign up** (gratuit)
3. Confirmez votre email

---

### Étape 2 — Créer un nouveau dépôt
1. Cliquez le **+** en haut à droite → **New repository**
2. Nom du dépôt : `suivi-paiements`
3. Cochez **Public** (obligatoire pour GitHub Pages gratuit)
4. Cliquez **Create repository**

---

### Étape 3 — Uploader les 5 fichiers
1. Dans votre dépôt, cliquez **uploading an existing file**
2. Glissez-déposez les **5 fichiers** en même temps :
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png`
   - `icon-512.png`
3. Cliquez **Commit changes**

---

### Étape 4 — Activer GitHub Pages
1. Allez dans **Settings** (onglet en haut du dépôt)
2. Dans le menu gauche, cliquez **Pages**
3. Sous **Source**, sélectionnez **Deploy from a branch**
4. Branche : **main** → dossier : **/ (root)**
5. Cliquez **Save**
6. Attendez 2-3 minutes ⏳

---

### Étape 5 — Votre URL est prête !
Votre app sera accessible à :
```
https://VOTRE_NOM_GITHUB.github.io/suivi-paiements/
```

---

## 📲 Installer sur votre téléphone

### Sur iPhone (Safari) :
1. Ouvrez l'URL dans **Safari** (pas Chrome !)
2. Appuyez sur l'icône **Partager** 📤 (en bas)
3. Faites défiler → **Sur l'écran d'accueil**
4. Appuyez **Ajouter** ✅
5. L'icône apparaît sur votre écran d'accueil 🎉

### Sur Android (Chrome) :
1. Ouvrez l'URL dans **Chrome**
2. Une bannière **"Ajouter à l'écran d'accueil"** apparaît automatiquement
3. Ou : Menu ⋮ → **Ajouter à l'écran d'accueil**
4. Appuyez **Installer** ✅
5. L'icône apparaît sur votre écran d'accueil 🎉

---

## ✅ Ce que vous obtenez

- 📱 Icône sur l'écran d'accueil comme une vraie app
- 🖥️ S'ouvre en plein écran (sans barre de navigateur)
- 📶 Fonctionne hors-ligne (données sauvegardées localement)
- 💾 Vos données sont stockées sur votre téléphone
- 🔒 Connexion HTTPS sécurisée (fournie par GitHub)

---

## ❓ Problème fréquent

**"Je ne vois pas l'option Ajouter à l'écran d'accueil"**
→ Assurez-vous d'utiliser **Safari sur iPhone** ou **Chrome sur Android**
→ Attendez que la page soit complètement chargée
→ L'URL doit commencer par `https://`

---

*Application créée avec Claude · Données 100% privées sur votre appareil*
